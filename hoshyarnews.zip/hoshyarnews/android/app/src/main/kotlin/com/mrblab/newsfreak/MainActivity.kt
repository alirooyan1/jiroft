package com.mrblab.newsfreak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
