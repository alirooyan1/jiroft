import 'package:flutter/material.dart';

class LockIcon{
  static const Icon lock = Icon(Icons.remove_red_eye_outlined, size: 20,);
  static const Icon open = Icon(Icons.remove_red_eye, size: 20,);
}