class CustomAdConfig{

  //Apllied in Inside listviews, Top and bottom of post details
  static double defaultBannerHeight = 160;

  //Applied in Top of the latest article in the home tab
  static double defaultPosterHeight = 250;
}